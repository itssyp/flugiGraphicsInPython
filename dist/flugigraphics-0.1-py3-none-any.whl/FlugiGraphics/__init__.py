# simplegraphics/__init__.py

from .graphics import *